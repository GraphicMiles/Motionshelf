# Nested menu

First-party MotionShelf UI example. Open `nested-menu.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Flyout with pointer, roving focus, Home/End, Escape and ArrowLeft close with focus return, danger styling on Share.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
