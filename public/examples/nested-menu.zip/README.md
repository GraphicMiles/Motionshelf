# Nested menu

First-party MotionShelf UI example. Open `nested-menu.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Arrow-key movement, submenu open/close rules, outside click, and touch targets.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
