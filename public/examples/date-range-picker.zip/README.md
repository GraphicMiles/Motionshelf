# Date range picker

First-party MotionShelf UI example. Open `date-range-picker.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Calendar navigation, blocked dates, range validation, and localized display.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
