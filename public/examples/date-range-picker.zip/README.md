# Date range picker

First-party MotionShelf UI example. Open `date-range-picker.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Monday-first weekday grid, hover preview band, inclusive night count, end-before-start normalisation, clear.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
