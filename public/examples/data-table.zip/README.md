# Data table

First-party MotionShelf UI example. Open `data-table.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Sortable headers, row selection, empty state, and mobile horizontal scrolling.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
