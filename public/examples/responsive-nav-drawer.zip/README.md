# Navigation drawer

First-party MotionShelf UI example. Open `responsive-nav-drawer.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Slide-in with scrim, focus trap, Escape, focus restoration, current-page marking.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
