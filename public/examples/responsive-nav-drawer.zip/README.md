# Navigation drawer

First-party MotionShelf UI example. Open `responsive-nav-drawer.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Open and close controls, focus return, scroll locking, and reduced-motion behavior.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
