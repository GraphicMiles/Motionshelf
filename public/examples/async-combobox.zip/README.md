# Async combobox

First-party MotionShelf UI example. Open `async-combobox.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Debounced queries, loading and error states, keyboard selection, and request cancellation.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
