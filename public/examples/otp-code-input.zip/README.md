# Verification code

First-party MotionShelf UI example. Open `otp-code-input.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Single logical input, numeric mode, paste support, and error and completion states.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
