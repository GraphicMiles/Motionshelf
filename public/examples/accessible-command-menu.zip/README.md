# Command menu

First-party MotionShelf UI example. Open `accessible-command-menu.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Grouped action list, subsequence matching with highlighted matches, gliding selection indicator, arrow keys, Escape to clear, Enter to run, live count and announcement.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
