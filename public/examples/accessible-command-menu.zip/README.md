# Command menu

First-party MotionShelf UI example. Open `accessible-command-menu.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Arrow-key navigation, Escape to close, accessible results announcements, and a command callback.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
