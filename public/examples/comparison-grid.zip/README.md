# Comparison grid

First-party MotionShelf UI example. Open `comparison-grid.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Accessible switch, check and cross marks, difference emphasis, live count.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
