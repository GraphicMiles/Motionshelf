# Comparison grid

First-party MotionShelf UI example. Open `comparison-grid.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Sticky labels on desktop, stacked rows on mobile, and explicit missing values.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
