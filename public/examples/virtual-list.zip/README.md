# Virtual list

First-party MotionShelf UI example. Open `virtual-list.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: 10,000 records, fixed row height, aria-posinset and aria-setsize, jump to top.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
