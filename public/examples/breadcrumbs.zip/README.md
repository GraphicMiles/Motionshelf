# Breadcrumb trail

First-party MotionShelf UI example. Open `breadcrumbs.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Ellipsis expands two hidden segments and collapses them again, focus moves to the revealed crumb.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
