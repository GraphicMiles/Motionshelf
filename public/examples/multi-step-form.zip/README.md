# Step form

First-party MotionShelf UI example. Open `multi-step-form.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Stepper with connector fill, per-step validation, radio group, preserved values when moving backwards, review panel.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
