# Pagination controls

First-party MotionShelf UI example. Open `pagination-controls.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Windowed page numbers with ellipsis, disabled previous and next at bounds, live range.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
