# Inline editor

First-party MotionShelf UI example. Open `inline-edit-field.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Edit in place, live 60-character counter, inline required error, Enter to save, Escape to discard, saved change history.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
