# Inline editor

First-party MotionShelf UI example. Open `inline-edit-field.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Edit and read modes, optimistic save feedback, Escape to cancel, and focus restoration.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
