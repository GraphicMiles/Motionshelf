# Activity timeline

First-party MotionShelf UI example. Open `activity-timeline.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Type filters, progressive load more, quoted comments, typed markers.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
