# Progress steps

First-party MotionShelf UI example. Open `progress-steps.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Current-step semantics, completed and blocked states, and compact mobile layout.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
