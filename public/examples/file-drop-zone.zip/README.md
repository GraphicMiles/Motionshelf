# File drop zone

First-party MotionShelf UI example. Open `file-drop-zone.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Keyboard file picker, drag-and-drop, size/type feedback, and a removable selection.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
