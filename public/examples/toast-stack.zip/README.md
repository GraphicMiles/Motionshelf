# Toast stack

First-party MotionShelf UI example. Open `toast-stack.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Four severities with icons, draining timer, pause on hover and focus, dismiss, three-item cap, empty state.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
