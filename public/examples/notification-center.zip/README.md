# Notification center

First-party MotionShelf UI example. Open `notification-center.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Unread emphasis, mark one read, unread filter, mark all read, empty state, correct pluralisation.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
