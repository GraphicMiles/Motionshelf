# Overflow tabs

First-party MotionShelf UI example. Open `overflow-tabs.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Roving focus, active-panel semantics, scroll-into-view, and narrow-screen overflow.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
