# Action confirmation

First-party MotionShelf UI example. Open `action-confirmation.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Modal with scrim and focus trap, Escape cancels, confirm removes with an undo countdown.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
