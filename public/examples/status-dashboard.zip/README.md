# Status dashboard

First-party MotionShelf UI example. Open `status-dashboard.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Timestamped values, unavailable-data labels, compact charts, and plain-language status.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
