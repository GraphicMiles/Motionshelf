# Filter bar

First-party MotionShelf UI example. Open `filter-bar.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Multi-select with counts, removal chips, clear all, empty state, announcement of visible count.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
