# Reading outline

First-party MotionShelf UI example. Open `table-of-contents.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Scroll spy with aria-current, progress rail, click-to-scroll, reduced-motion aware.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
