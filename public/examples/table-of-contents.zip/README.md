# Reading outline

First-party MotionShelf UI example. Open `table-of-contents.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Heading discovery, active-section tracking, reduced-motion scrolling, and deep links.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
