# Kanban lanes

First-party MotionShelf UI example. Open `kanban-lanes.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Native drag-and-drop across lanes, add task, live counts, announcements.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
