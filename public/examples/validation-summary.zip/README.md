# Validation summary

First-party MotionShelf UI example. Open `validation-summary.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Field-level errors, summary links, focus management, and screen-reader announcements.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
