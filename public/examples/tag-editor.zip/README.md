# Tag editor

First-party MotionShelf UI example. Open `tag-editor.html` in a browser or serve it from a local static server. Its script and stylesheet are the exact files used by the live preview. No dependencies, network requests, or build steps are needed.

Target interaction: Duplicate prevention, Enter and Backspace behavior, paste handling, and readable selected tags.

The example is licensed under the MotionShelf MIT license. Keep the included license notice when redistributing.
