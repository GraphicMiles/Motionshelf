# Issue Duplicate Finder

A first-party, offline MotionShelf agent tool. It reads the supplied JSON and produces a bounded, evidence-first report; it does not execute code, fetch remote content, or change repository files. Outputs are heuristics for human review, not verified conclusions.

## Run

```sh
node issue-duplicate-finder.mjs sample.json
```

Requires Node.js 20 or newer. See `sample.json` for the input structure. Keep the three `.mjs` files together. Input must be a JSON file under 1 MB.

Licensed under the MotionShelf MIT license; retain the license notice in the repository.
